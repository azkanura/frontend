<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width" initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/style.css')); ?>" rel="stylesheet">

</head>
<body>
    <section class="container">
        <header>
            <img class="logo" src="<?php echo e(url('public/img/logo.png')); ?>" alt="Bukalapak" title="Bukalapak" />
            <a class="refresh" style="background-image: url('<?php echo e(url('public/img/sprite.png')); ?>')">
            </a>
        </header>
        <?php echo $__env->yieldContent('content'); ?>
    </section>
    <script src="<?php echo e(asset('public/public/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('public/public/js/script.js')); ?>"></script>
</body>
</html>
