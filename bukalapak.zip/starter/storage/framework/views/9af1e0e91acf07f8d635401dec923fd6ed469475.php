<?php $__env->startSection('content'); ?>
    <div class="section-title">
        Pilih Kategori:
        <a class="section-close">

        </a>
    </div>
    <ul class="category-list">
        <li class="list-item sub-category"><a><span class="icon-sub" style="background-image: url('<?php echo e(url('public/img/sprite.png')); ?>')"></span>Batu Cincin</a></li>
        <li class="list-item sub-category"><a><span class="icon-sub" style="background-image: url('<?php echo e(url('public/img/sprite.png')); ?>')"></span>Buku</a></li>
        <li class="list-item sub-category"><a><span class="icon-sub" style="background-image: url('<?php echo e(url('public/img/sprite.png')); ?>')"></span>Elektronik</a></li>
        <li class="list-item sub-category"><a><span class="icon-sub" style="background-image: url('<?php echo e(url('public/img/sprite.png')); ?>')"></span>Elektronik</a></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>